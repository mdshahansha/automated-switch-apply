# Freshteam and Zoho Recruit: 24-hour source checks

Window: **25 October 2026 14:06:45 IST–26 October 2026 14:06:45 IST** (2026-10-25T08:36:45Z–2026-10-26T08:36:45Z).

Five Freshteam postings disclose source `JobPosting.datePosted` within the window. Two Zoho postings disclose today's `Date_Opened`, with no exact publication time. Neither portal produced a high-confidence strong-fit recommendation from this sample. No applications were submitted.

| Platform | Company / role | Source publication evidence | Fit / limitation |
|---|---|---|---|
| Freshteam | [CynLr — Web Developer](https://cynlr.freshteam.com/jobs/KS0Cln4QM62S/web-developer) | 25 October, 17:41:13 IST | Bengaluru office; description is only a dash, so requirements are unknown. |
| Freshteam | [RemoteStar — Software Engineer (AI Agents)](https://remotestar-team.freshteam.com/jobs/kQBqtgAStRnu/software-engineer-ai-agents) | 26 October, 12:20:34 IST | Remote-first, Gurugram preferred. Requires production Python and hands-on AI agents; not confirmed in profile. |
| Freshteam | [Cashflo — Asp.net Fullstack Developer](https://cashflo-talent.freshteam.com/jobs/OW6oDfqpHKTo/asp-net-fullstack-developer) | 26 October, 12:29:57 IST | Mumbai; C#/.NET and migration experience required. Stack gap. |
| Freshteam | [RemoteStar — Senior Frontend Developer](https://remotestar-team.freshteam.com/jobs/7IOfIZWwbVEC/senior-frontend-developer) | 26 October, 11:20:11 IST | Bengaluru; React/Node/Next overlap, but 9+ years required. |
| Freshteam | [RemoteStar — SMTS (Backend Engineer) (Remote)](https://remotestar-team.freshteam.com/jobs/joQEkH4C7S1l/smts-backend-engineer-remote) | 25 October, 17:11:06 IST | Source lists Bengaluru/Pune/Noida/Hyderabad; discovery aggregator incorrectly labeled UK. Requires Python/Golang and 5–8 years. |
| Zoho Recruit | [Prescience — Senior React Engineer](https://prescienceds.zohorecruit.in/jobs/Careers/91154000013324157) | Date Opened: 26 October 2026; portal timezone Asia/Kolkata | Exact time absent; 7+ years required. |
| Zoho Recruit | [Prescience — Senior Backend Engineer (Python)](https://prescienceds.zohorecruit.in/jobs/Careers/91154000013324143) | Date Opened: 26 October 2026; portal timezone Asia/Kolkata | Exact time absent; 6+ years in description / 7+ in metadata, and Python required. |

Freshteam HTML was fetched with the repository's robots-gated, identifying GET helper. Zoho's public HTML supplied its job record and timezone. Search crawl timestamps and aggregator posting dates were not accepted as publication proof. All seven fetched pages passed `posting_guard` without instruction-like findings. Guarded description extracts are saved in `freshteam-zoho-evidence/`.

Today's Zoho date is compatible with the requested period because today's IST day began at 25 October 18:30 UTC. The report preserves the actual `Date_Opened` label; it does not invent a timestamp. A source publication field cannot independently prove the requisition has never been advertised before.

Nine other Freshteam role pages were excluded after source dates proved older than the window. One Crimson Interactive lead remains undated and is not counted. This is a discovery sample, not a claim that every employer on either ATS was scanned. Machine-readable details and exclusions: `freshteam-zoho.json`.
