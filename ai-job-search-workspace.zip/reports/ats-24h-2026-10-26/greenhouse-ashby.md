# Greenhouse and Ashby: last 24 hours

Window: **25 October 2026, 14:06:45 IST through 26 October 2026, 14:06:45 IST**.

Checked 19 Greenhouse and 15 Ashby public employer boards, containing 2656 open postings before geography/role filtering. Four additional Greenhouse board tokens and one Ashby token returned 404; these are access/token failures, not evidence that individual jobs closed.

**0 core full-stack/backend/Java/React/React Native roles verified as newly published within this window.** One adjacent infrastructure role had a timestamp in the window.

## Timestamp-verified adjacent role

| Role | Employer | Location | Source publication | Fit limitation |
|---|---|---|---|---|
| [Infrastructure Engineer](https://jobs.ashbyhq.com/sarvam/f09b6a35-e2d1-4833-8bc5-2b495991d882) | Sarvam | Bengaluru, onsite | 2026-10-26T06:29:28.519+00:00 | DevOps/SRE/infrastructure work; Python/Go/Bash, Docker/Kubernetes, on-call; 2-5 years |

Ashby `publishedAt` is documented as **last published**, so it can represent republication. Greenhouse `first_published` is used for first publication. `updated_at` is never accepted as publication.

## Aggregator leads rejected after source verification

| Role | Employer | Source first publication | Recent update | Reason |
|---|---|---|---|---|
| [Software Engineer](https://job-boards.greenhouse.io/turing/jobs/6115695004) | Turing | 2026-07-15T13:20:07-04:00 | 2026-10-25T14:11:04-04:00 | First publication is outside 24 hours |
| [Cloud Engineer II](https://www.tracelink.com/about/culture-and-careers/jobs?gh_jid=5232181007) | TraceLink, Inc | 2026-09-08T09:31:59-04:00 | 2026-10-26T00:54:23-04:00 | First publication is outside 24 hours |
| [Software Architect I](https://www.tracelink.com/about/culture-and-careers/jobs?gh_jid=5057488007) | TraceLink, Inc | 2026-06-24T05:37:55-04:00 | 2026-10-26T00:52:06-04:00 | First publication is outside 24 hours |
| [Software Engineer, Senior](https://www.tracelink.com/about/culture-and-careers/jobs?gh_jid=5198967007) | TraceLink, Inc | 2026-08-20T03:35:54-04:00 | 2026-10-26T00:52:41-04:00 | First publication is outside 24 hours |

The Turing aggregator timestamp equals the official Greenhouse update timestamp, not its July first-publication timestamp. The TraceLink leads likewise first appeared months before their recent updates.

## Coverage and evidence

This is a bounded sample of public employer boards, not every employer on either ATS. Search-engine crawl dates and snippets were discovery leads only. No login, application, or resume upload was performed.

Full checked-board list, original publication timestamps, source URLs, adjacent-role description, old candidate details and errors: [greenhouse-ashby.json](greenhouse-ashby.json).

Public API documentation: [Greenhouse Job Board API](https://docs.greenhouse.io/job-board), [Ashby Job Postings API](https://developers.ashbyhq.com/docs/public-job-posting-api).

## Additional remote lead rejected for location

[Clera — Founding Engineer](https://jobs.ashbyhq.com/clera/d1fb19d4-3e2e-4367-b24a-f397a16491eb) has verified `publishedAt` **2026-10-25T17:03:38.541Z**, within the window. Although structured location says only `remote`, the original description requires **remote within Europe** and relocation to **San Francisco within the first year**. Excluded for an India-based applicant. Source evidence: [clera-source.json](clera-source.json).
