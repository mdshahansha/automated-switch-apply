# Lever and SmartRecruiters: last-24-hour verification

Window: **25 October 2026 14:06:45–26 October 2026 14:06:45 IST** (UTC 08:36:45–08:36:45). Read-only official public sources; identifying User-Agent.

**No strong/medium development match verified in the bounded boards checked.** This does not mean either ATS has no jobs platform-wide.

| ATS | Fresh candidate | Primary date evidence | Disposition |
|---|---|---|---|
| SmartRecruiters | [Principal Software Engineer](https://jobs.smartrecruiters.com/Eurofins/744000157672029-principal-software-engineer) | 2026-10-25T13:42:22.942Z (releasedDate) | All four ads contain the same Principal Software Engineer requirements: 7–10 years and .NET/C#/ASP.NET plus Angular. Candidate has ~3 years in Java/Node/React, no confirmed .NET/Angular. Similar content and minute-spaced releases are a distribution pattern, not four distinct strong matches. |
| SmartRecruiters | [.Net Fullstack Engineer](https://jobs.smartrecruiters.com/Eurofins/744000157671939--net-fullstack-engineer) | 2026-10-25T13:41:50.389Z (releasedDate) | All four ads contain the same Principal Software Engineer requirements: 7–10 years and .NET/C#/ASP.NET plus Angular. Candidate has ~3 years in Java/Node/React, no confirmed .NET/Angular. Similar content and minute-spaced releases are a distribution pattern, not four distinct strong matches. |
| SmartRecruiters | [Dot Net Fullstack Developer (Angular)](https://jobs.smartrecruiters.com/Eurofins/744000157672109-dot-net-fullstack-developer-angular-) | 2026-10-25T13:43:10.113Z (releasedDate) | All four ads contain the same Principal Software Engineer requirements: 7–10 years and .NET/C#/ASP.NET plus Angular. Candidate has ~3 years in Java/Node/React, no confirmed .NET/Angular. Similar content and minute-spaced releases are a distribution pattern, not four distinct strong matches. |
| SmartRecruiters | [.Net Angular Developer](https://jobs.smartrecruiters.com/Eurofins/744000157672059--net-angular-developer) | 2026-10-25T13:42:49.305Z (releasedDate) | All four ads contain the same Principal Software Engineer requirements: 7–10 years and .NET/C#/ASP.NET plus Angular. Candidate has ~3 years in Java/Node/React, no confirmed .NET/Angular. Similar content and minute-spaced releases are a distribution pattern, not four distinct strong matches. |
| Lever | [Fullstack QA Engineer (MSME)](https://jobs.lever.co/jobgether/34ebecc0-c88b-413d-8c10-bafde63a3ccd) | 2026-10-26 (JobPosting.datePosted) | Requires at least 3 years specifically in QA/software testing with mobile-product testing. Candidate targets development; 3 years QA experience is not supported. End employer is undisclosed. |

The four Eurofins ads share the same principal-level Microsoft-stack description and were released within 80 seconds; treat as related distribution, not four separate good matches.

Jobgether QA has `datePosted: 2026-10-26` in the public page. Its API `createdAt` is `2026-10-26T01:11:23.287Z`; exact publication time is not exposed. It is retained as an adjacent-role exclusion, not a strict timestamp-confirmed development match.

QAD Software / Full Stack Engineer is a useful 2–4 year skill match, but the public API release is **16 October**, so it is excluded from this 24-hour request.

Coverage: 9 Lever company feeds, 7 reproducibly enumerated SmartRecruiters company feeds; selected feeds are capped at 250/100 records. An additional ASSYSTEM probe returned no fresh relevant candidate. No global all-employer completeness claimed.

See `lever-smart.json` for endpoints, bounds, dates and exclusions; `lever-smart-details.json` for captured detail evidence.
